<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>While</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<a href="index.php">Retour</a><br>
				<?php $max = isset($_GET["max"]) ? $_GET["max"] : 10; ?>
					$i=0;<br>
					while(++$i) {<br>
						if($i == $max) {<br>
							exit($max." : Fin du script...");<br>
						}<br>
						else {<br>
							echo $i;<br>
						}<br>
					}<br>
					echo "Retour du script (ne sera pas affiché)";<br>
				<br>				
				<?php
					$i=0;
					while(++$i) {
						if($i == $max) {
							exit($max." : Fin du script...");
						}
						else {
							echo $i."<br>";
						}
					}
					echo "Retour du script (ne sera pas affiché)";
				?>
			</div>
			<div id="footer">
				<a href="index.php">Retour</a>
			</div>
		</div>
   </body>
</html>