<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Tableaux à 1 dimension</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					$mots=["Je","fais","du","PHP","!"];
				?>
				<?php
					for($i=0;$i<count($mots);$i++) {
						echo $mots[$i]." ";
					}
				?>
				<br><br>
				<?php echo '<pre>Mots : ' . var_export($mots, true) . '</pre>'; ?>
				<?php 
					$splice = $mots;
					$unset = $mots;
					array_splice($splice,1,1);
					echo '<pre>Suppr : ' . var_export($splice, true) . '</pre>';
					unset($unset[1]);
					echo '<pre>Annul : ' . var_export($unset, true) . '</pre>';
					array_push($splice,"fais");
					echo '<pre>Ajout sur suppr : ' . var_export($splice, true) . '</pre>';
					array_push($unset,"fais");
					echo '<pre>Ajout sur annul : ' . var_export($unset, true) . '</pre>';
					array_splice($splice,1,0,"fais");
					echo '<pre>Insertion sur suppr : ' . var_export($splice, true) . '</pre>';
					array_splice($unset,1,0,"fais");
					echo '<pre>Insertion sur annul : ' . var_export($unset, true) . '</pre>';
				?>
				<?php
					$phrase = "";
					foreach($mots as $m) {
						$phrase.=$m.' ';
					}
					echo $phrase;
					echo "<br>";
					echo implode(" ",$mots);
				?>
			</div>
			<div id="footer">
				<a href="J5-Tableaux-2.php">Suite</a>
			</div>
		</div>
   </body>
</html>