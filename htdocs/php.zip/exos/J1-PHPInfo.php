<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>PHPInfo</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php phpinfo(); ?>
			</div>
			<div id="footer">
				<a href="J1-UserAgent.php">Suite</a>
			</div>
		</div>
   </body>
</html>