<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Formulaire</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<form action="J1-Reponse.php" method="GET">
					Votre nom :<input type="text" name="nom">
					Votre âge :<input type="text" name="age">
					<input type="password" name="hidden" value="cookie" />
					<p>
					<input type=submit value="Envoyer">
				</form>
			</div>
			<div id="footer">
				<a href="J1-Reponse.php">Suite</a>
			</div>
		</div>
   </body>
</html>