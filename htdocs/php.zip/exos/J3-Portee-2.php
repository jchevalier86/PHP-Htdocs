<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Portée des variables</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					require_once("fonctions.php");
					echo "noCompteur() => ";
					echo noCompteur(); //0
					echo "<br>";
					echo "noCompteur() => ";
					echo noCompteur();
					echo "<br>";
					echo "noCompteur() => ";
					echo noCompteur();
					echo "<br>";
					echo "<br>";
					echo "compteur() => ";
					echo compteur(); //0
					echo "<br>";
					echo "compteur() => ";
					echo compteur();
					echo "<br>";
					echo "compteur() => ";
					echo compteur();
					echo "<br>";
				?>
			</div>
			<div id="footer">
				<a href="J3-Namespace.php">Suite</a>
			</div>
		</div>
   </body>
</html>