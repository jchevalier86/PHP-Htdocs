<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Variables</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				$a = 1000;<br>
				$b = "1000";<br>
				if($a == $b)<br>
				{<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo "\$a est égal à \$b";<br>
				}<br>
				else<br>
				{<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo "\$a est différent de \$b";<br>
				}<br>
				<?php
					$a = 1000;
					$b = "1000";
					if($a == $b)
					{
						echo "\$a est égal à \$b";
					}
					else
					{
						echo "\$a est différent de \$b";
					}
				?>
				<br>
				<br>
				$a = 1000;<br>
				$b = "1000";<br>
				if($a === $b)<br>
				{<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo "\$a est égal à \$b";<br>
				}<br>
				else<br>
				{<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo "\$a est différent de \$b";<br>
				}<br>
				<?php
					$a = 1000;
					$b = "1000";
					if($a === $b)
					{
						echo "\$a est égal à \$b";
					}
					else
					{
						echo "\$a est différent de \$b";
					}
				?>
				<br>
				<br>
				$a = 1000;<br>
				$b = "1000";<br>
				echo ($a === $b) ? "\$a est égal à \$b" : "\$a est différent de \$b";<br>
				<?php
					$a = 1000;
					$b = "1000";
					echo ($a === $b) ? "\$a est égal à \$b" : "\$a est différent de \$b";
				?>
			</div>
			<div id="footer">
				<a href="J2-ElseIf.php?numero=0579960187">Suite</a>
			</div>
		</div>
   </body>
</html>