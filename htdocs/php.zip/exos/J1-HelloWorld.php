<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title> Bonjour depuis PHP </title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php echo 'Hello World !'; ?>
			</div>
			<div id="footer">
				<a href="J1-PHPInfo.php">Suite</a>
			</div>
		</div>
   </body>
</html>