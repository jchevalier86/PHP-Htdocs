<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Bases de données</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.4.0/styles/default.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.4.0/highlight.min.js"></script>
		<script>hljs.highlightAll();</script>
<style>
  
</style>
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<button class="accordion">Exercice 1 - Écrivez un script PHP pour récupérer et afficher tous les utilisateurs de la base de données avec leur nom, prénom, email</button>
				<div class="panel">
					<div class="code-container">
						<pre><code class="php code">
&lt;table border="1"&gt;
&lt;tr&gt;&lt;th&gt;Prénom&lt;/th&gt;&lt;th&gt;Nom&lt;/th&gt;&lt;th&gt;Email&lt;/th&gt;&lt;/tr&gt;
&lt;?php
require_once("connect.php");
$req = "SELECT id, prenom, nom, email FROM utilisateurs;";
$curs = $mysqli->query($req);
if($curs->num_rows>0){
	while($tuple = $curs->fetch_object()){
		echo "&lt;tr&gt;&lt;td&gt;".$tuple->prenom."&lt;/td&gt;&lt;td&gt;".$tuple->nom."&lt;/td&gt;&lt;td&gt;".$tuple->email."&lt;/td&gt;&lt;/tr&gt;";
	}
}
?&gt;
&lt;table&gt;
						</code></pre>
						<div>
							
						</div>
					</div>
				</div>
				<table style="border:1px solid black;">
					<tr><th>Prénom</th><th>Nom</th><th>Email</th></tr>
					<?php
						require_once("connect.php");
						$req = "SELECT prenom, nom, email FROM utilisateurs;";
						$curs = $mysqli->query($req);
						if($curs->num_rows>0){
							while($tuple = $curs->fetch_object()){
								echo "<tr style=\"border:1px solid black;\"><td>".$tuple->prenom."</td><td>".$tuple->nom."</td><td>".$tuple->email."</td></tr>";
							}
						}
					?>
				<table>
				<button class="accordion">Exercice 2 : Écrivez une requête SQL pour insérer un nouvel utilisateur dans la table "utilisateurs".</button>
				<div class="panel">
					<div class="code-container">
						<pre><code class="php code">
&lt;?php
	require_once("connect.php");
	$req="INSERT INTO utilisateurs VALUES (null, 'Thomas', 'Girardeau', 'tgirardeau', 'thomas.girardeau@ifpa86.fr', 1987, 'Poitiers', 86);";
	$mysqli->query($req);
	if($mysqli->affected_rows > 0 ){
		echo "Utilisateur ajouté";
	}
?&gt;
						</code></pre>
					</div>
				</div>
				<button class="accordion">Exercice 3 : Créez un formulaire HTML permettant à l'utilisateur d'ajouter un nouvel utilisateur avec son nom, prénom, email, année de naissance, ville. Écrivez un script PHP pour traiter les données soumises et les insérer dans la base de données.</button>
				<div class="panel">
					<div class="code-container">
						Fichier html
						<pre><code class="html code">
&lt;form method="get" action=""&gt;
	Prénom : &lt;input type="text" name="prenom"&gt;&lt;br&gt;
	Nom : &lt;input type="text" name="nom"&gt;&lt;br&gt;
	Email : &lt;input type="text" name="email"&gt;&lt;br&gt;
	Année : &lt;input type="text" name="annee"&gt;&lt;br&gt;
	Ville : &lt;input type="text" name="ville"&gt;&lt;br&gt;
	&lt;input type="submit" value="Créer un utilisateur"&gt;
&lt;/form&gt;
						</code></pre>
						<form method="get" action="">
							Prénom : <input type="text" name="prenom"><br>
							Nom : <input type="text" name="nom"><br>
							Email : <input type="text" name="email"><br>
							Année : <input type="text" name="annee"><br>
							Ville : <input type="text" name="ville"><br>
							<input type="submit" value="Créer un utilisateur">
						</form>
						<p></p>
						Fichier php
						<pre><code class="php code">
&lt;?php
	require_once("connect.php");
	if(isset($_GET["prenom"]) && isset($_GET["nom"]) && isset($_GET["email"]) && isset($_GET["annee"]) && isset($_GET["ville"])){
		$req="INSERT INTO utilisateurs VALUES (null, '".$_GET["prenom"]."', '".$_GET["nom"]."', '', '".$_GET["email"]."', ".$_GET["annee"].", '".$_GET["ville"]."', null);";
		$mysqli->query($req);
		if($mysqli->affected_rows > 0 ){
			echo "Utilisateur ajouté";
		}
	}
?&gt;
<?php
	/*require_once("connect.php");
	if(isset($_GET["prenom"]) && isset($_GET["nom"]) && isset($_GET["email"]) && isset($_GET["annee"]) && isset($_GET["ville"])){
		$req="INSERT INTO utilisateurs VALUES (null, '".$_GET["prenom"]."', '".$_GET["nom"]."', '', '".$_GET["email"]."', ".$_GET["annee"].", '".$_GET["ville"]."', null);";
		$mysqli->query($req);
		if($mysqli->affected_rows > 0 ){
			echo "Utilisateur ajouté";
		}
	}*/
?>
						</code></pre>
					</div>
				</div>
				<button class="accordion">Exercice 4 : Affichez une liste des utilisateurs avec une option pour supprimer chaque utilisateur individuellement. Écrivez un script PHP pour supprimer l'utilisateur sélectionné de la base de données lorsqu'il clique sur le bouton de suppression.</button>
				<div class="panel">
					<div class="code-container">
						<pre><code class="php code">
<?php
	/*require_once("connect.php");
	$id=0;
	$tuple=null;
	if(isset($_GET["action"])){
		if($_GET["action"]=="delete"){
			if(isset($_GET["id"])){
				$req="DELETE FROM utilisateurs WHERE id='".$_GET["id"]."';";
				$mysqli->query($req);
				if($mysqli->affected_rows > 0 ){
					echo "Utilisateur supprimé";
				}
			}
		} elseif($_GET["action"]=="select") {
			if($_GET["id"]!==""){
				$id=$_GET["id"];
				$req="SELECT * FROM utilisateurs WHERE id='".$id."';";
				$curs=$mysqli->query($req);
				if($curs->num_rows === 0 ){
					echo "ID ".$id." non trouvé.";	//Ne devrait pas se produire
				}
				else {
					$tuple = $curs->fetch_object();
				}
			}
		}
	}*/
?>
&lt;?php
	require_once("connect.php");
	$id=0;
	$tuple=null;
	if(isset($_GET["action"])){
		if($_GET["action"]=="delete"){
			if(isset($_GET["id"])){
				$req="DELETE FROM utilisateurs WHERE id='".$_GET["id"]."';";
				$mysqli->query($req);
				if($mysqli->affected_rows > 0 ){
					echo "Utilisateur supprimé";
				}
			}
		}
	}
?&gt;
&lt;form method="get" action="exobdd.php"&gt;
	&lt;select name="id"&gt;
		&lt;?php
			$req="SELECT * FROM utilisateurs;";
			$cursAll=$mysqli->query($req);
			while($tupleAll=$cursAll->fetch_object()){ 
				echo "&lt;option value=\"".$tupleAll->id."\"&gt;".$tupleAll->prenom." ".$tupleAll->nom."&lt;/option&gt;";
			}
		?&gt;
	&lt;/select&gt;
	&lt;input type="hidden" name="action" value="delete"&gt;
	&lt;input type="submit" value="Supprimer"&gt;
&lt;/form&gt;
						</code></pre>
						<form method="get" action="exobdd.php">
							<select name="id"&gt;
								<?php
									$req="SELECT * FROM utilisateurs;";
									$cursAll=$mysqli->query($req);
									while($tupleAll=$cursAll->fetch_object()){ 
										echo "<option value=\"".$tupleAll->id."\">".$tupleAll->prenom." ".$tupleAll->nom."</option>";
									}
								?>
							</select>
							<input type="hidden" name="action" value="delete">
							<input type="submit" value="Supprimer">
						</form>
					</div>
				</div>
				<button class="accordion">Exercice 5 : Permettez à l'utilisateur de sélectionner un utilisateur existant à partir d'une liste déroulante et de modifier ses informations (nom, prénom, email, etc.) à l'aide d'un formulaire. Écrivez un script PHP pour mettre à jour les informations de l'utilisateur sélectionné dans la base de données.</button>
				<div class="panel">
					<div class="code-container">
						Partie php
						<pre><code class="php code">
&lt;?php
	require_once("connect.php");
	$id=0;
	$tuple=null;
	if(isset($_GET["action"])){
		if($_GET["action"]=="update"){
			if(isset($_GET["id"]) && isset($_GET["prenom"]) && isset($_GET["nom"]) && isset($_GET["email"]) && isset($_GET["annee"]) && isset($_GET["ville"])){
				$req="UPDATE utilisateurs SET prenom='".$_GET["prenom"]."', nom='".$_GET["nom"]."', email='".$_GET["email"]."', annee_naissance=".$_GET["annee"].", ville='".$_GET["ville"]."' WHERE id='".$_GET["id"]."';";
				$mysqli->query($req);
				if($mysqli->affected_rows > 0 ){
					echo "Utilisateur mis à jour";
				}
			}
		} elseif($_GET["action"]=="select") {
			if($_GET["id"]!==""){
				$id=$_GET["id"];
				$req="SELECT * FROM utilisateurs WHERE id='".$id."';";
				$curs=$mysqli->query($req);
				if($curs->num_rows === 0 ){
					echo "ID ".$id." non trouvé.";	//Ne devrait pas se produire
				}
				else {
					$tuple = $curs->fetch_object();
				}
			}
		}
	}
?&gt;
<?php
	require_once("connect.php");
	$id=0;
	$tuple=null;
	if(isset($_GET["action"])){
		if($_GET["action"]=="update"){
			if(isset($_GET["id"]) && isset($_GET["prenom"]) && isset($_GET["nom"]) && isset($_GET["email"]) && isset($_GET["annee"]) && isset($_GET["ville"])){
				$req="UPDATE utilisateurs SET prenom='".$_GET["prenom"]."', nom='".$_GET["nom"]."', email='".$_GET["email"]."', annee_naissance=".$_GET["annee"].", ville='".$_GET["ville"]."' WHERE id='".$_GET["id"]."';";
				$mysqli->query($req);
				if($mysqli->affected_rows > 0 ){
					echo "Utilisateur mis à jour";
				}
			}
		} elseif($_GET["action"]=="select") {
			if($_GET["id"]!==""){
				$id=$_GET["id"];
				$req="SELECT * FROM utilisateurs WHERE id='".$id."';";
				$curs=$mysqli->query($req);
				if($curs->num_rows === 0 ){
					echo "ID ".$id." non trouvé.";	//Ne devrait pas se produire
				}
				else {
					$tuple = $curs->fetch_object();
				}
			}
		}
	}
?>
						</code></pre>
						Partie html
						<pre><code class="html code">
&lt;form method="get" action="exobdd.php"&gt;
	&lt;select name="id"&gt;
		&lt;?php
			$req="SELECT * FROM utilisateurs;";
			$cursAll=$mysqli->query($req);
			while($tupleAll=$cursAll->fetch_object()){ 
				echo "&lt;option value=\"".$tupleAll->id."\"&gt;".$tupleAll->prenom." ".$tupleAll->nom."&lt;/option&gt;";
			}
		?&gt;
	&lt;/select&gt;
	&lt;input type="hidden" name="action" value="select"&gt;
	&lt;input type="submit" name="Selection"&gt;
&lt;/form&gt;
&lt;form method="get" action="exobdd.php"&gt;
	Prénom : &lt;input type="text" name="prenom" value="&lt;?php echo isset($tuple) ? $tuple->prenom : "" ; ?&gt"&gt;&lt;br&gt;
	Nom : &lt;input type="text" name="nom" value="&lt;?php echo isset($tuple) ? $tuple->nom : "" ; ?&gt"&gt;&lt;br&gt;
	Email : &lt;input type="text" name="email" value="&lt;?php echo isset($tuple) ? $tuple->email : "" ; ?&gt"&gt;&lt;br&gt;
	Année : &lt;input type="text" name="annee" value="&lt;?php echo isset($tuple) ? $tuple->annee_naissance : "" ; ?&gt"&gt;&lt;br&gt;
	Ville : &lt;input type="text" name="ville" value="&lt;?php echo isset($tuple) ? $tuple->ville : "" ; ?&gt"&gt;&lt;br&gt;
	&lt;input type="hidden" name="action" value="update"&gt;
	&lt;input type="hidden" name="id" value="&lt;?php echo isset($id) ? $id : "" ; ?&gt;"&gt;
	&lt;input type="submit" value="Mettre à jour"&gt;
&lt;/form&gt;
						</code></pre>
						<form method="get" action="exobdd.php">
							<select name="id">
								<?php
									$req="SELECT * FROM utilisateurs;";
									$cursAll=$mysqli->query($req);
									while($tupleAll=$cursAll->fetch_object()){ 
										echo "<option value=\"".$tupleAll->id."\">".$tupleAll->prenom." ".$tupleAll->nom."</option>";
									}
								?>
							</select>
							<input type="hidden" name="action" value="select">
							<input type="submit" value="Selection">
						</form>
						<form method="get" action="exobdd.php">
							Prénom : <input type="text" name="prenom" value="<?php echo isset($tuple) ? $tuple->prenom : "" ; ?>"><br>
							Nom : <input type="text" name="nom" value="<?php echo isset($tuple) ? $tuple->nom : "" ; ?>"><br>
							Email : <input type="text" name="email" value="<?php echo isset($tuple) ? $tuple->email : "" ; ?>"><br>
							Année : <input type="text" name="annee" value="<?php echo isset($tuple) ? $tuple->annee_naissance : "" ; ?>"><br>
							Ville : <input type="text" name="ville" value="<?php echo isset($tuple) ? $tuple->ville : "" ; ?>"><br>
							<input type="hidden" name="action" value="update">
							<input type="hidden" name="id" value="<?php echo isset($id) ? $id : "" ; ?>">
							<input type="submit" value="Mettre à jour">
						</form>
					</div>
				</div>
				<button class="accordion">Exercice 6 : Créez un formulaire de recherche qui permet à l'utilisateur de rechercher des utilisateurs par leur nom ou leur email. Affichez les résultats de la recherche sous forme de liste.</button>
				<div class="panel">
					<div class="code-container">
						<pre><code class="php code">
&lt;?php
// Code PHP avec coloration syntaxique
$variable = "Hello, world!";
echo $variable;
?&gt;
						</code></pre>
					</div>
				</div>
			</div>
		</div>		
	  <script>
		var accordions = document.getElementsByClassName("accordion");
		var i;
		
		for (i = 0; i < accordions.length; i++) {
			accordions[i].addEventListener("click", function() {
				this.classList.toggle("active");
				var panel = this.nextElementSibling;
				if (panel.style.maxHeight) {
					panel.style.maxHeight = null;
				} else {
					panel.style.maxHeight = panel.scrollHeight + "px";
				}
			});
		}
</script>
   </body>
</html>