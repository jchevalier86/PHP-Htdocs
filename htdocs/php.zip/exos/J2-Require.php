<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Require</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				require("regions.php");<br>
				echo $region;<br>
				<br>
				<?php
					require("regions.php");
					echo $region;
				?>
			</div>
			<div id="footer">
				<a href="index.php">Retour</a>
			</div>
		</div>
   </body>
</html>