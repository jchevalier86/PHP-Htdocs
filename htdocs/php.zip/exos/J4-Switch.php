<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>While</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php $max = isset($_GET["max"]) ? $_GET["max"] : 10; ?>
				<?php $min = isset($_GET["min"]) ? $_GET["min"] : 1; ?>
				<?php $moy = floor(($min+$max)/2); ?>
				//Afficher tous les nombres de <?php echo $min." à ".$max; ?><br>
				//en soulignant <?php echo $moy; ?> et <?php echo $max; ?> en italique<br>
				$i = <?php echo ($min-1); ?>;<br>
				while(++$i) {<br>
					switch($i) {<br>
						case <?php echo $moy; ?>:<br>
							echo "< u >$i< /u >";<br>
							break 1;<br>
						case <?php echo $max; ?>:<br>
							echo "< i >$i< /i >";<br>
							break 2;<br>
						default:<br>
							echo $i;<br>
							break;<br>
					}<br>
				}<br>
				<br>
				<?php
					//Afficher tous les nombres de $min à $max
					//en soulignant $moy et $max en italique
					$i = ($min-1);
					while(++$i) {
						switch($i) {
							case $moy:
								echo "<u>$i</u><br>";
								break 1;
							case $max:
								echo "<i>$i</i><br>";
								break 2;
							default:
								echo $i."<br>";
								break;
						}
					}
				?>
			</div>
			<div id="footer">
				<a href="J4-Exit.php?max=10">Suite</a>
			</div>
		</div>
   </body>
</html>