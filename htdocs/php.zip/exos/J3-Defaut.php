<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Défaut</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					require_once("fonctions.php");
					echo "<u>Paramètres par défaut </u><br>";
					echo "Je s'appelle .defaut(\"Thomas\") => ";
					echo "Je s'appelle ".defaut("Thomas");
					echo "<br>";
					echo "Je s'appelle .defaut() => ";
					echo "Je s'appelle ".defaut();
					
					echo "<br><br>";
					echo "<u>Paramètres nommés </u><br>";
					echo cafe();										//Je bois mon café noir sans sucre dans une tasse.
					echo "<br>";
					echo cafe(contenant : "un bol", sucre : "avec du");	//Je bois mon café noir avec du sucre dans un bol.
				?>
			</div>
			<div id="footer">
				<a href="J3-Portee.php">Suite</a>
			</div>
		</div>
   </body>
</html>