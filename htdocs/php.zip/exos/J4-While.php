<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>While</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php $max = isset($_GET["max"]) ? $_GET["max"] : 5; ?>
				//Afficher tous les nombres de 1 à <?php echo $max; ?><br>
				$i=1;<br>
				while($i<=<?php echo $max; ?>) {<br>
					echo $i;<br>
					$i++;<br>
				}<br>
				<br>
				<?php
					//Afficher tous les nombres de 1 à $max
					$i=1;
					while($i<=$max) {
						echo $i."<br>";
						$i++;
					}
				?>
				<br><br>
			</div>
			<div id="footer">
				<a href="J4-DoWhile.php?min=1&max=5">Suite</a>
			</div>
		</div>
   </body>
</html>