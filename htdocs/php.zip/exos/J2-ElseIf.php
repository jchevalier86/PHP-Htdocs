<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Variables</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
					$numero=$_GET["numero"];<br>
					$prefixe=substr($numero,0,2);	//05<br>
					if($prefixe==="01") {<br>
						echo "Paris et région parisienne";<br>
					} else {<br>
						if($prefixe==="02") {<br>
							echo "Nord-ouest, Réunion et Mayotte";<br>
						} else {<br>
							if($prefixe==="03") {<br>
								echo "Nord-est";<br>
							} else {<br>
								if($prefixe==="04") {<br>
									echo "Sud-est";<br>
								} else {<br>
									if($prefixe==="05") {<br>
										echo "Sud-ouest, DOM-COM Atlantique";<br>
									}<br>
								}<br>
							}<br>
						}<br>
					}<br>
				<?php
					$numero=$_GET["numero"];
					$prefixe=substr($numero,0,2);	//05
					if($prefixe==="01") {
						echo "Paris et région parisienne";
					} else {
						if($prefixe==="02") {
							echo "Nord-ouest, Réunion et Mayotte";
						} else {
							if($prefixe==="03") {
								echo "Nord-est";
							} else {
								if($prefixe==="04") {
									echo "Sud-est";
								} else {
									if($prefixe==="05") {
										echo "Sud-ouest, DOM-COM Atlantique";
									}
								}
							}
						}
					}						
				?>
				<br><br>
				$numero=$_GET["numero"];<br>
					$prefixe=substr($numero,0,2);	//05<br>
					if($prefixe==="01") {<br>
						echo "Paris et région parisienne";<br>
					} elseif($prefixe==="02") {<br>
						echo "Nord-ouest, Réunion et Mayotte";<br>
					} elseif($prefixe==="03") {<br>
						echo "Nord-est";<br>
					} elseif($prefixe==="04") {<br>
						echo "Sud-est";<br>
					} elseif($prefixe==="05") {<br>
						echo "Sud-ouest, DOM-COM Atlantique";<br>
					}<br>
				<?php
					$numero=$_GET["numero"];
					$prefixe=substr($numero,0,2);	//05
					if($prefixe==="01") {
						echo "Paris et région parisienne";
					} elseif($prefixe==="02") {
						echo "Nord-ouest, Réunion et Mayotte";
					} elseif($prefixe==="03") {
						echo "Nord-est";
					} elseif($prefixe==="04") {
						echo "Sud-est";
					} elseif($prefixe==="05") {
						echo "Sud-ouest, DOM-COM Atlantique";
					}						
				?>
			</div>
			<div id="footer">
				<a href="J2-Require.php?numero=0579960187">Suite</a>
			</div>
		</div>
   </body>
</html>