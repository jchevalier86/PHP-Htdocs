<?php
	require_once("connect.php");
	if($CONNEXION) {
		if(isset($_GET["login"])&&(isset($_GET["password"]))){
			$req=$mysqli->prepare("SELECT * FROM utilisateurs WHERE login=? AND password=?;");
			$req->bind_param("ss",$_GET["login"],$_GET["password"]);
			$req->execute();
			//echo "<br>";
			$curs=$req->get_result();
			if($curs->num_rows>0){
				$tuple=$curs->fetch_object();
				echo "Utilisateur connecté : ".$tuple->prenom." ".$tuple->nom;
			}
			else {
				echo "Utilisateur inconnu.";
			}
		}
	}
?>
<form method="get" action="bdd2.php">
	Login : <input type="text" name="login" value="<?php echo isset($_GET["login"]) ? $_GET["login"] : "" ; ?>"><br>
	Password : <input type="text" name="password" value="<?php echo isset($_GET["password"]) ? $_GET["password"] : "" ; ?>"><br>
	<input type="submit">
</form>