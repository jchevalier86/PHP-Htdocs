<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Tableaux à 1 dimension</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					$user = ['Utilisateur' => 'Thomas', 'Nom' => 'Girardeau', 'Email' => 'thomas.girardeau@ifpa86.fr', 'Telephone' => '0579960187'];
					echo '<pre>' . var_export($user, true) . '</pre>';
					$user['Utilisateur'] = 'Thomas';
					$user['Nom'] = 'Girardeau';
					$user['Email'] = 'thomas.girardeau@ifpa86.fr';
					$user['Telephone'] = '0579960187';
					echo '<pre>' . var_export($user, true) . '</pre>';
					$user = array('Utilisateur' => 'Thomas', 'Nom' => 'Girardeau', 'Email' => 'thomas.girardeau@ifpa86.fr', 'Telephone' => '0579960187');
					echo '<pre>' . var_export($user, true) . '</pre>';
				?>
			</div>
			<div id="footer">
				<a href="J5-Tableaux-1.php">Suite</a>
			</div>
		</div>
   </body>
</html>