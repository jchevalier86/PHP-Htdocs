<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Fonctions</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					require_once("fonctions.php");
					echo multiplication(2,3,4,5,6,7,8,9,10);
					echo "<br><br>";
					echo "<u>Passage par valeur : </u><br>";
					echo "\$val = 2";
					$val = 2;
					echo "<br>";
					echo "doubleValeur(\$val); => ";
					echo doubleValeur($val);
					echo "<br>";
					echo "\$val = ".$val;
					echo "<br><br>";
					echo "<u>Passage par référence : </u><br>";
					echo "\$val = 2";
					$val = 2;
					echo "<br>";
					echo "doubleReference(\$val); => ";
					echo doubleReference($val);
					echo "<br>";
					echo "\$val = ".$val;
				?>
			</div>
			<div id="footer">
				<a href="J3-Defaut.php">Suite</a>
			</div>
		</div>
   </body>
</html>