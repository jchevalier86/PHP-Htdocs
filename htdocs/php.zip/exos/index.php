<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" type="text/css" href="main.css" />
		<title>PHP</title>
	</head>
	<body>
		<div id="page-container">
			<div id="content-wrap">
				<p><a href="J1-HelloWorld.php">Jour 1</a></p>
				<p><a href="J2-Variables.php">Jour 2</a></p>
				<p><a href="J3-Fonctions.php">Jour 3</a></p>
				<p><a href="J4-Boucles.php">Jour 4</a></p>
				<p><a href="J5-Superglobales.php">Jour 5</a></p>
				<p><a href="J1-PHPInfo.php">Jour 6</a></p>
				<p><a href="J1-PHPInfo.php">Jour 7</a></p>
			</div>
			<div id="footer">
				
			</div>
		</div>
	</body>
</html>