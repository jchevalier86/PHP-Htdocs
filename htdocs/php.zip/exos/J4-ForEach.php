<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>While</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php $max = isset($_GET["max"]) ? $_GET["max"] : 5; ?>
				<?php $min = isset($_GET["min"]) ? $_GET["min"] : 1; ?>
				<?php
					$val=[];
					for($i=$min;$i<=$max;$i++) {
						array_push($val,$i);
					}
				?>
				//Afficher tous les nombres de <?php echo $min." à ".$max; ?><br>
				$nombres = [<?php echo implode(",",$val); ?>];<br>
				foreach ($nombres as $n) {<br>
					echo $n;<br>
				}<br>
				<br>
				<?php
					//Afficher tous les nombres de $min à $max
					$nombres = $val;
					foreach ($nombres as $n) {
						echo $n."<br>";
					}
				?>
			</div>
			<div id="footer">
				<a href="J4-Switch.php?min=1&max=10">Suite</a>
			</div>
		</div>
   </body>
</html>