<?php
	require_once("connect.php");
	$req=$mysqli->prepare("SELECT * FROM utilisateurs WHERE id=?");
	$req->bind_param('i',$_GET["id"]);
	$req->execute();
	$curs=$req->get_result();
	if($curs->num_rows>0){
		$tuple=$curs->fetch_object();
?>
	<form method="get" action="exobdd.php">
		Prénom : <input type="text" name="prenom" value="<?php echo isset($tuple) ? $tuple->prenom : "" ; ?>"><br>
		Nom : <input type="text" name="nom" value="<?php echo isset($tuple) ? $tuple->nom : "" ; ?>"><br>
		Email : <input type="text" name="email" value="<?php echo isset($tuple) ? $tuple->email : "" ; ?>"><br>
		Année : <input type="text" name="annee" value="<?php echo isset($tuple) ? $tuple->annee_naissance : "" ; ?>"><br>
		Ville : <input type="text" name="ville" value="<?php echo isset($tuple) ? $tuple->ville : "" ; ?>"><br>
		<input type="hidden" name="action" value="update">
		<input type="hidden" name="id" value="<?php echo isset($id) ? $id : "" ; ?>">
		<input type="submit" value="Mettre à jour">
	</form>
<?php
	}
	else {
		echo "Utilisateur introuvable.";
	}
?>