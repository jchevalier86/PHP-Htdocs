<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>While</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php $max = isset($_GET["max"]) ? $_GET["max"] : 5; ?>
				<?php $min = isset($_GET["min"]) ? $_GET["min"] : 1; ?>
				//Afficher tous les nombres de <?php echo $min; ?> à <?php echo $max; ?><br>
				for($i=<?php echo $min; ?>;$i<=<?php echo $max; ?>;$i++) {<br>
					echo $i;<br>
				}<br>
				<br>
				<?php
					//Afficher tous les nombres de $min à $max
					for($i=$min;$i<=$max;$i++) {
						echo $i."<br>";
					}
				?>
			</div>
			<div id="footer">
				<a href="J4-ForEach.php?min=1&max=5">Suite</a>
			</div>
		</div>
   </body>
</html>