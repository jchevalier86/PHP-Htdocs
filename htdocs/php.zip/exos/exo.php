<?php 
	$valide=false;
	$email="";
	if(isset($_GET["email"])) {
		$email = $_GET["email"];
		$posAr = strpos($email,"@");
		$posPo = strpos($email, ".");
		if($posAr < $posPo && $posAr !== false) {
			$valide = true;
		}
	}
?>
<form action="exo.php" method="GET">
	<input type="text" value="<?php echo $email; ?>" name="email">
	<input type="submit" value="Envoyer" />
</form>
<?php
	//echo $valide ? "Adresse valide" : "Adresse incorrecte";
	$id=10;
	$prenom="Thomas";
	$nom="Girardeau";
?>
<br>
<select name="choix">
<?php
	echo sprintf("<option value='%s'>%s %s</option>",$id,$prenom,$nom);
?>
</select>