<?php
	Namespace MonProjet {
		const a = 1;
		function valeur() {
			echo a;
		}
	}
	Namespace AutreProjet {
		const a = 2;
		function valeur() {
			echo a;
		}
	}
	
	Namespace {
		const a = 0;
		function valeur() {
			echo a;
		}
	}
?>