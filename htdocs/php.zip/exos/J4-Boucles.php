<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Boucles</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				//Afficher tous les nombres de 1 à 5<br>
				$i=1;<br>
				echo "$i";<br>
				$i=2;<br>
				echo "$i";<br>
				echo $i=3;<br>
				$i=4;<br>
				echo "$i;<br>
				echo ($i=5);
				<br><br>
				<?php
					//Afficher tous les nombres de 1 à 5
					$i=1;
					echo "$i"."<br>";
					$i=2;
					echo "$i"."<br>";
					echo $i=3;
					echo "<br>";
					$i=4;
					echo "$i"."<br>";
					echo ($i=5)."<br>";
				?>
				<br><br>
				//Afficher tous les nombres de 1 à 5<br>
				for($i=1;$i<=5;$i++) {<br>
					echo $i;<br>
				}<br>
				<br><br>
				<?php
					//Afficher tous les nombres de 1 à 5
					for($i=1;$i<=5;$i++) {
						echo $i."<br>";
					}
				?>
			</div>
			<div id="footer">
				<a href="J4-While.php?max=5">Suite</a>
			</div>
		</div>
   </body>
</html>