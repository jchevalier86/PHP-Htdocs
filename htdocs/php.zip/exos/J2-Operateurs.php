<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Variables</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				// Nombre flottants<br>
				echo 1.5 <=> 1.5; // 0<br>
				echo 1.5 <=> 2.5; // -1<br>
				echo 2.5 <=> 1.5; // 1<br><br>
				
				// Chaines de caractères<br>
				echo "a" <=> "a"; // 0<br>
				echo "a" <=> "b"; // -1<br>
				echo "b" <=> "a"; // 1<br><br>

				// Tableaux<br>
				echo [] <=> []; // 0<br>
				echo [1, 2, 3] <=> [1, 2, 3]; // 0<br>
				echo [1, 2, 3] <=> []; // 1<br>
				echo [1, 2, 3] <=> [1, 2, 1]; // 1<br>
				echo [1, 2, 3] <=> [1, 2, 4]; // -1<br><br>

				<?php
				echo "Nombre flottants";
				echo "<br>";
				echo 1.5 <=> 1.5; // 0
				echo "<br>";
				echo 1.5 <=> 2.5; // -1<br>
				echo "<br>";
				echo 2.5 <=> 1.5; // 1<br><br>
				echo "<br>";
				
				echo "<br>";
				echo "Chaines de caractères";
				echo "<br>";
				echo "a" <=> "a"; // 0<br>
				echo "<br>";
				echo "a" <=> "b"; // -1<br>
				echo "<br>";
				echo "b" <=> "a"; // 1<br><br>
				echo "<br>";
				echo "<br>";

				echo "Tableaux";
				echo "<br>";
				echo [] <=> []; // 0<br>
				echo "<br>";
				echo [1, 2, 3] <=> [1, 2, 3]; // 0<br>
				echo "<br>";
				echo [1, 2, 3] <=> []; // 1<br>
				echo "<br>";
				echo [1, 2, 3] <=> [1, 2, 1]; // 1<br>
				echo "<br>";
				echo [1, 2, 3] <=> [1, 2, 4]; // -1<br><br>
				?>
			</div>
			<div id="footer">
				<a href="J2-IF.php">Suite</a>
			</div>
		</div>
   </body>
</html>