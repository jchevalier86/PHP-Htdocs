<?php
	function maFonction($param1,$param2) {
		//Action
		return $resultat;
	}
	function multiplication(...$nombres) {
		$res = 1;
		foreach ($nombres as $n) {
			$res *= $n;
		}
		return $res;
	}
	
	function doubleValeur($val) {
		echo $val = $val * 2;
	}
	
	function doubleReference(&$val) {
		echo $val = $val * 2;
	}
	
	function defaut($nom = "Groot") {
		return $nom;
	}
	
	function cafe($contenant = "une tasse", $parfum = "noir", $sucre = "sans") {
		return "Je bois mon café $parfum $sucre sucre dans $contenant.";
	}
	
	function nombre() {
		return [0, 1, 2];
	}
	
	function noCompteur()	{
		$a = 0;
		echo $a;
		$a++;
	}
	
	function compteur()	{
		static $a = 0;
		echo $a;
		$a++;
	}
	
	while($i<=10) {
		echo $i."<br>";
	}
?>