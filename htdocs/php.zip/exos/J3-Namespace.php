<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Namespaces</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					require("namespace.php");
					echo "a = ".a;	//0
					echo "<br>";
					echo "MonProjet\a = ".MonProjet\a;
					echo "<br>";
					echo "AutreProjet\a = ".AutreProjet\a;
					echo "<br>";
					echo "AutreProjet\\valeur() => ";
					AutreProjet\valeur();
					echo "<br>";
					echo "<br>";
					echo "<u>Alias</u><br>";
					//Alias d'un namespace
					use AutreProjet as LeProjet;
					echo "LeProjet\a = ".LeProjet\a;
					echo "<br>";
					use function MonProjet\valeur as val;
					echo "val() => ";
					val();
				?>
			</div>
			<div id="footer">
				<a href="index.php">Retour</a>
			</div>
		</div>
   </body>
</html>