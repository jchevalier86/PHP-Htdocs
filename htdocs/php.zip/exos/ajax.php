<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>AJAX</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div>
			<select name="choix" id="choix" onchange="showLine()">
			<?php
				require_once("connect.php");
				$req="select * from utilisateurs;";
				$curs=$mysqli->query($req);
				if($curs->num_rows > 0){
					while($tuple=$curs->fetch_object()){
						echo sprintf("<option value='%s'>%s %s</option>",$tuple->id,$tuple->prenom,$tuple->nom);
					}
				}
			?>
			</select>
		</div>
		<div id="result">
			
		</div>
		<script>
			function showLine(){
				//alert(document.getElementById("choix").value);
				var id = document.getElementById("choix").value;
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("result").innerHTML =
						this.responseText;
				   }
				};
				xhttp.open("GET", "ajax2.php?id=" + id, true);
				xhttp.send();
			}
		</script>
   </body>
</html>