<?php
	$numero=$_GET["numero"];
	$prefixe=substr($numero,0,2); //05
	if($prefixe==="01") {
		$region = "Paris et région parisienne";
	} elseif($prefixe==="02") {
		 $region = "Nord-ouest, Réunion et Mayotte";
	} elseif($prefixe==="03") {
		 $region = "Nord-est";
	} elseif($prefixe==="04") {
		 $region = "Sud-est";
	} elseif($prefixe==="05") {
		 $region = "Sud-ouest, DOM-COM Atlantique";
	}
?>