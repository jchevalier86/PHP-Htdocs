<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>While</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php $max = isset($_GET["max"]) ? $_GET["max"] : 5; ?>
				<?php $min = isset($_GET["min"]) ? $_GET["min"] : 1; ?>
				//Afficher tous les nombres de <?php echo $min; ?> à <?php echo $max; ?><br>
				$i=<?php echo $min; ?>;<br>
				do {<br>
					echo $i;<br>
					$i++;<br>
				}<br>
				while($i<=<?php echo $max; ?>);<br>
				<br>
				<?php
					//Afficher tous les nombres de $min à $max
					$i=$min;
					do {
						echo $i."<br>";
						$i++;
					}
					while($i<=$max);
				?>
			</div>
			<div id="footer">
				<a href="J4-For.php?min=1&max=5">Suite</a>
			</div>
		</div>
   </body>
</html>