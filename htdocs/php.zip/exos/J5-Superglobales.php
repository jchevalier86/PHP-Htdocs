<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Boucles</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<p>$GLOBALS : <br><?php echo '<pre>' . var_export($GLOBALS, true) . '</pre>'; ?></p>
				<p>$_SERVER : <br><?php echo '<pre>' . var_export($_SERVER, true) . '</pre>'; ?></p>
				<p>$_ENV : <br><?php echo '<pre>' . var_export(getenv(), true) . '</pre>'; ?></p>
			</div>
			<div id="footer">
				<a href="J5-Tableaux-1.php">Suite</a>
			</div>
		</div>
   </body>
</html>