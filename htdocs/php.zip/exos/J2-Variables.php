<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Variables</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					$variable = "une variable en PHP";
					// Une autre variable :
					$Variable = 1000;
					// Type dynamique :
					$var = "Chaine";  		 // Type string
					echo "\$var est du type " . gettype($var) . "<br>";
					$var = 1000;		 // Type int
					echo "\$var est du type " . gettype($var) . "<br>";
					$var = 10.005;		 // Type float, double, real
					echo "\$var est du type " . gettype($var) . "<br>";
					$var = true;		 // Type bool
					echo "\$var est du type " . gettype($var) . "<br>";
				?>
			</div>
			<div id="footer">
				<a href="J2-Operateurs.php">Suite</a>
			</div>
		</div>
   </body>
</html>