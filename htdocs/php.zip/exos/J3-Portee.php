<!doctype html>
<html>
   <head>
      <meta charset="utf-8" />
      <title>Portée des variables</title>
	  <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body>
		<div id="page-container">
			<div id="content-wrap">
				<?php
					$a = 1; // Portée globale
					
					function globcale1() {
						echo $a;
					}
					globcale1();	// Warning: Undefined variable $a
					echo "<br>";
					function globcale2() {
						global $a;
						echo $a;
					}
					globcale2();	// 1
					echo "<br>";
					function globcale3() {
						echo $GLOBALS['a'];
					}
					globcale3();	// 1
				?>
			</div>
			<div id="footer">
				<a href="J3-Portee-2.php">Suite</a>
			</div>
		</div>
   </body>
</html>