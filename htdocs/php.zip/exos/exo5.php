<?php
	/*const pSeuil = 2.3;
	const vSeuil = 7.41;
	
	$pression = $_GET["p"];
	$volume = $_GET["v"];
	
	echo "P=".$pression." - Seuil : ".pSeuil;
	echo "<br>V=".$volume." - Seuil : ".vSeuil;
	echo "<br>";
	
	if($volume > vSeuil && $pression > pSeuil) {
		echo "Arret immédiat";
	}
	elseif($pression > pSeuil) {
		echo "Augmenter le volume de l'enceinte";
	}
	elseif($volume > vSeuil) {
		echo "Diminuer le volume de l'enceinte";
	}
	else{
		echo "Tout va bien";
	}*/
	const a = 1;
	const b = 2;
	
	echo a < b ? a : b;
?>